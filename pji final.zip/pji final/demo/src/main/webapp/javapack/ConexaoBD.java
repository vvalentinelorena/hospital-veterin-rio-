import org.apache.jasper.tagplugins.jstl.core.Import;

public class ConexaoBD {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String banco, usuario, senha;
		
		Connection conexaoBD = null;
		PreparedStatement cmdSQL = null;
		ResultSet rsSet = null;
		
		try{
			banco = "jdbc:mysql://localhost/hospitalveterinariodb";
			usuario = "root";
			senha = "";
			
			Class.forName("com.mysql.jdbc.Driver");
			
			conexaoBD = DriverManager.getConnection(banco, usuario, senha);
			
			out.println("<h3>Conex�o efetuada com sucesso!</h3>");
			
		}
		catch(Exception ex){
			out.println("<h3>Erro: " + ex.getMessage()  + "</h3>");
			return;
		}

	}

}
